# 01-calculator
(1) Create a program that asks the users for two numbers then displays a sentence as seen below. *The example below is what your screen should look like if you run the program with sample inputs. Do not include the sample inputs in the output of your code.*
```
Enter a number:
1
Enter a second number:
2
Doing math for 1 and 2.
```
(2) Expand the program to preform seven mathematical operations in the order shown below.
```
Enter a number:
1
Enter a second number:
2
Doing math for 1 and 2.

Addition = 3
Subtraction = -1
Multiplication = 2
Exponent = 1
Division = 0.5
Floor Division = 0
Modulus Division = 1
```
(3) Expand the program to round the division to a maximum of 3 decimal places.
```
Enter a number:
1
Enter a second number:
16
Doing math for 1 and 16.

Addition = 17
Subtraction = -15
Multiplication = 16
Exponent = 1
Division = 0.062
Floor Division = 0
Modulus Division = 1
```
