#Charles Hayes
#Period 4
num1=int(input('Enter a number:\n'))
num2=int(input('Enter a second number:\n'))
print(f"Doing math for {num1} and {num2}.")
print(f"Addition={num1+num2}\nSubtraction={num1-num2}\nMultiplication={num1*num2}\nExponent={num1**num2}\nDivision={round((num1/num2),3)}")
